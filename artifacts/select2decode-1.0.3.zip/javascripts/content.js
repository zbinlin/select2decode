(function (textEncoding) {
'use strict';

textEncoding = 'default' in textEncoding ? textEncoding['default'] : textEncoding;

var TextDecoder = textEncoding.TextDecoder;


var DICT = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
function base64Decode(str) {
    str = str.replace(/\s/g, "");
    var len = Math.floor(str.length / 4);
    var ary = [];
    for (var i = 0; i < len; i++) {
        var idx = i * 4;
        var a = DICT.indexOf(str[idx]);
        var b = DICT.indexOf(str[idx + 1]);
        var c = DICT.indexOf(str[idx + 2]);
        var d = DICT.indexOf(str[idx + 3]);
        if (a === -1 || b === -1 || c === -1 || d === -1) {
            throw new Error("invalid base64 string");
        }
        ary.push(a << 2 | b >> 4);
        if (c < 64) {
            ary.push((b << 4 | c >> 2) & 0xFF);
            if (d < 64) {
                ary.push((c << 6 | d) & 0xFF);
            }
        }
    }
    return ary;
}



function decode(base64String) {
    var encoding = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "UTF-8";

    var ary = base64Decode(base64String);
    if (encoding === "hex") {
        return ary.map(function (ch) {
            return ch.toString(16);
        }).join("");
    }
    var decoder = new TextDecoder(encoding);
    var u8Ary = new Uint8Array(ary.length);
    for (var i = 0, len = ary.length; i < len; i++) {
        u8Ary[i] = ary[i];
    }
    return decoder.decode(u8Ary);
}

var container = null;

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg.action !== "decode-select-text") {
        return;
    }
    if (!document.activeElement) return;
    doDecode();
});

function doDecode() {
    popup();
}

function getSelection() {
    var activeEl = document.activeElement;
    var selectedString = void 0;
    var range = void 0;
    if (activeEl instanceof HTMLInputElement || activeEl instanceof HTMLTextAreaElement) {
        range = new Range();
        selectedString = activeEl.value.slice(activeEl.selectionStart, activeEl.selectionEnd);
        // TODO
        return null;
    } else {
        var selection = window.getSelection();
        selectedString = selection.toString();
        range = selection.getRangeAt(0);
    }
    if (!selectedString) return null;
    var rect = range.getBoundingClientRect();
    return {
        width: rect.width,
        height: rect.height,
        top: rect.top,
        bottom: rect.bottom,
        left: rect.left,
        right: rect.right,
        content: selectedString
    };
}

function convertPointFromViewportToNode(point, node) {
    if (typeof node.convertPointFromNode === "function") {
        return node.convertPointFromNode(point, document, {
            fromBox: "border",
            toBox: "border"
        });
    } else {
        var rect = node.getBoundingClientRect();
        return {
            x: point.x - rect.left,
            y: point.y - rect.top
        };
    }
}

function detectPosition(rect, target) {
    var top = rect.top,
        bottom = rect.bottom,
        left = rect.left,
        width = rect.width,
        height = rect.height;

    var ancestor = getClosestPositionedAncestor();

    var _convertPointFromView = convertPointFromViewportToNode({
        x: left,
        y: top
    }, ancestor),
        x = _convertPointFromView.x,
        y = _convertPointFromView.y;

    var offsetBottom = document.documentElement.clientHeight - bottom;

    var placement = "bottom";
    if (offsetBottom < target.height && top > target.height) {
        placement = "top";
    }

    var ox = x + width / 2;
    x += (width - target.width) / 2;
    y = placement === "bottom" ? y + height : y - target.height, x = Math.min(Math.max(document.documentElement.scrollWidth, document.body.scrollWidth) - target.width, Math.max(0, x));

    return {
        placement: placement,
        x: x,
        y: y,
        indicatorX: Math.max(0, ox - x - 18),
        width: target.width,
        height: target.height
    };
}

function getClosestPositionedAncestor() {
    var body = document.body;
    if (window.getComputedStyle(body).position !== "static") {
        return body;
    } else {
        return document.documentElement;
    }
}

function decodeAndAppendTo(elem, content, encoding) {
    var FAILURE = "<p style=\"color: red; font-style: italic\">\u89E3\u7801\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u6240\u9009\u7684\u6587\u672C\u662F\u5426\u662F base64 \u7F16\u7801\u7684\u6587\u672C</p>";
    var decoded = void 0;
    try {
        decoded = decode(content, encoding);
    } catch (ex) {
        console.error(ex);
    }
    if (decoded !== undefined) {
        elem.textContent = decoded;
    } else {
        elem.innerHTML = FAILURE;
    }
}
function createContentLayer(content) {
    var elem = document.createElement("div");
    var className = "__s2s-content-" + Date.now() + "__";
    var html = "\n        <div class=\"__s2d_handler__\">\n            <div class=\"__s2d_indicator__\"></div>\n        </div>\n        <div class=\"__s2d-header-container__\">\n            <div class=\"__s2d-select-container__\">\n                <select>\n                    <option value=\"UTF-8\" selected>UTF-8</option>\n                    <option value=\"hex\">Hex</option>\n                    <option value=\"gbk\">GBK/GB2312</option>\n                </select>\n            </div>\n            <div class=\"__s2d-copy-container__\">\n                <a class=\"__s2d-copy-btn__\" title=\"\u590D\u5236\u5230\u526A\u8D34\u677F\">Copy</a>\n            </div>\n        </div>\n        <div class=\"__s2d-content-conatiner__\">\n            <div class=\"" + className + "\"></div>\n        </div>\n    ";
    elem.innerHTML = html;
    var select = elem.querySelector("select");
    var ct = elem.querySelector("." + className);
    decodeAndAppendTo(ct, content);
    select.addEventListener("change", function (evt) {
        var encoding = evt.target.value;
        decodeAndAppendTo(ct, content, encoding);
    });
    var copyBtn = elem.querySelector(".__s2d-copy-btn__");
    copyBtn.addEventListener("click", function (evt) {
        var cls = "__s2d-copy-btn--copying__";
        copyBtn.classList.add(cls);
        evt.preventDefault();
        document.addEventListener("copy", function _(evt) {
            document.removeEventListener("copy", _);
            evt.preventDefault();
            evt.clipboardData.setData("text/plain", ct.textContent);
            copyBtn.classList.remove(cls);
        });
        document.execCommand("copy");
    });
    return elem;
}

function createPopupUI() {
    var selection = getSelection();
    if (!selection) return;
    var layer = {
        width: 320,
        height: (7 * 1.8 + 0.5) * 14 + 38
    };
    var pos = detectPosition(selection, layer);
    if (!container) {
        container = document.createElement("div");
        container.classList.add("__s2d-container__");
    } else {
        container.className = "__s2d-container__";
    }
    if (pos.placement === "top") {
        container.classList.add("__s2d-placement-top__");
    } else {
        container.classList.add("__s2d-placement-bottom__");
    }
    container.style.cssText = "\n        left: " + pos.x + "px;\n        top: " + pos.y + "px;\n        width: " + pos.width + "px;\n        height: " + pos.height + "px;\n    ";
    var contentLayer = createContentLayer(selection.content);
    var indicator = contentLayer.querySelector(".__s2d_indicator__");
    indicator.style.left = pos.indicatorX + "px";
    container.innerHTML = "";
    container.appendChild(contentLayer);
    return container;
}

function resizeUI(container) {
    container.classList.add("__s2d-resizing__");
    var height = (4 * 1.8 + 0.5) * 14;
    var ct = container.querySelector(".__s2d-content-conatiner__");
    if (ct.clientHeight > height) return;
    var containerHeight = container.clientHeight;
    var nHeight = height + 38;
    if (container.classList.contains("__s2d-placement-top__")) {
        container.style.top = parseInt(container.style.top, 10) + (containerHeight - nHeight) + "px";
    }
    container.style.height = nHeight + "px";
    container.classList.remove("__s2d-resizing__");
}

function popup() {
    var container = createPopupUI();
    if (!container) return;
    document.body.appendChild(container);
    resizeUI(container);
    container.classList.add("__s2d-show__");
}

document.addEventListener("click", function (evt) {
    if (!container) return;
    var target = evt.target;
    if (!container.contains(target)) {
        container.classList.remove("__s2d-show__");
    }
});

}(window));
